import { TOGGLE_DONE_TODO } from './types'
export default id => ({
    type: TOGGLE_DONE_TODO,
    payload: id,
})
