import { REMOVE_TODO } from './types'

export default id => ({ type: REMOVE_TODO, payload: id })
