import { createStore } from 'redux'
import {
    ADD_TODO,
    REMOVE_TODO,
    TOGGLE_DONE_TODO,
    COMPLETE_ALL_TODO,
} from './actions/types'

const todoReducer = (state = [], { type, payload }) => {
    if (type === ADD_TODO) {
        return [payload, ...state]
    }

    if (type === TOGGLE_DONE_TODO) {
        // const todos = [...state]
        // const index = todos.findIndex(todo => todo.id === payload)
        // todos[index].completed = !todos[index].completed
        // return todos

        return [...state, state.filter(todo => todo.id !== payload)]
    }

    if (type === COMPLETE_ALL_TODO) {
        const todos = [...state]
        return todos.filter(todo => !todo.completed)
    }
    console.log(type)
    if (type === REMOVE_TODO) {
        return state.filter(todo => todo.id !== payload)
    }

    return state
}

const store = createStore(
    todoReducer,
    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
)

export default store
