import React, { Component } from 'react'
import Footer from './components/Footer'
import Header from './components/Header'
import { connect } from 'react-redux'
import removeTodo from './store/actions/removeTodo'
import toggleDoneTodo from './store/actions/toggleDoneTodo'
class TodoApp extends Component {
    render() {
        return (
            <div>
                <section className="todoapp">
                    <Header />
                    <section className="main">
                        <input
                            id="toggle-all"
                            className="toggle-all"
                            type="checkbox"
                        />
                        <label htmlFor="toggle-all">Mark all as complete</label>
                        <ul className="todo-list">
                            {this.props.todos.map(todo => (
                                <li
                                    className={
                                        todo.completed ? `completed` : null
                                    }
                                    key={todo.id}
                                >
                                    <div className="view">
                                        <input
                                            className="toggle"
                                            type="checkbox"
                                            checked={todo.completed}
                                            onChange={e =>
                                                this.props.toggleDone(todo.id)
                                            }
                                        />
                                        <label>{todo.task}</label>
                                        <button
                                            className="destroy"
                                            onClick={e =>
                                                this.props.remove(todo.id)
                                            }
                                        />
                                    </div>
                                    <input
                                        className="edit"
                                        defaultValue="Create a TodoMVC template"
                                    />
                                </li>
                            ))}
                        </ul>
                    </section>
                    <Footer />
                </section>
            </div>
        )
    }
}

export default connect(
    state => ({ todos: state }),
    dispatch => ({
        remove: id => dispatch(removeTodo(id)),
        toggleDone: id => dispatch(toggleDoneTodo(id)),
    })
)(TodoApp)
